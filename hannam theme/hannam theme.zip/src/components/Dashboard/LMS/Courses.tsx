
import React, { useState } from "react";
import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import {Link} from "react-router-dom";

type Course = {
  id: number;
  name: string;
  viewLink: string;
  category: string;
  instructor: {
    name: string;
    image: string;
  };
  enrolled: number;
  startDate: string;
  endDate: string;
  price: string;
};

const initialCourses: Course[] = [
  {
    id: 854,
    name: "Cybersecurity Awareness",
    viewLink: "/lms/course-details",
    category: "Technology",
    instructor: { name: "Oliver Khan", image: "/images/users/user6.jpg" },
    enrolled: 180,
    startDate: "25 Mar 2024",
    endDate: "25 Apr 2024",
    price: "$49.99",
  },
  {
    id: 853,
    name: "Python Programming",
    viewLink: "/lms/course-details",
    category: "Science",
    instructor: { name: "Ava Cooper", image: "/images/users/user7.jpg" },
    enrolled: 250,
    startDate: "20 Mar 2024",
    endDate: "20 Apr 2024",
    price: "$45.32",
  },
  {
    id: 852,
    name: "Big Data Analytics",
    viewLink: "/lms/course-details",
    category: "Health & Wellness",
    instructor: { name: "Isabella Evans", image: "/images/users/user8.jpg" },
    enrolled: 320,
    startDate: "15 Mar 2024",
    endDate: "15 Apr 2024",
    price: "$99.00",
  },
  {
    id: 851,
    name: "Introduction to Blockchain",
    viewLink: "/lms/course-details",
    category: "Education",
    instructor: { name: "Mia Hughes", image: "/images/users/user9.jpg" },
    enrolled: 135,
    startDate: "10 Mar 2024",
    endDate: "10 Apr 2024",
    price: "$29.75",
  },
  {
    id: 850,
    name: "Network Administration",
    viewLink: "/lms/course-details",
    category: "Food & Cooking",
    instructor: { name: "Noah Mitchell", image: "/images/users/user10.jpg" },
    enrolled: 460,
    startDate: "05 Mar 2024",
    endDate: "05 Apr 2024",
    price: "$56.99",
  },
  {
    id: 849,
    name: "Artificial Intelligence",
    viewLink: "/lms/course-details",
    category: "Lifestyle & Fashion",
    instructor: { name: "Olivia Lucy", image: "/images/users/user11.jpg" },
    enrolled: 515,
    startDate: "10 Feb 2024",
    endDate: "10 Mar 2024",
    price: "$78.75",
  },
  {
    id: 852,
    name: "Big Data Analytics",
    viewLink: "/lms/course-details",
    category: "Health & Wellness",
    instructor: { name: "Isabella Evans", image: "/images/users/user8.jpg" },
    enrolled: 320,
    startDate: "15 Mar 2024",
    endDate: "15 Apr 2024",
    price: "$99.00",
  },
  {
    id: 854,
    name: "Cybersecurity Awareness",
    viewLink: "/lms/course-details",
    category: "Technology",
    instructor: { name: "Oliver Khan", image: "/images/users/user6.jpg" },
    enrolled: 180,
    startDate: "25 Mar 2024",
    endDate: "25 Apr 2024",
    price: "$49.99",
  },
  {
    id: 850,
    name: "Network Administration",
    viewLink: "/lms/course-details",
    category: "Food & Cooking",
    instructor: { name: "Noah Mitchell", image: "/images/users/user10.jpg" },
    enrolled: 460,
    startDate: "05 Mar 2024",
    endDate: "05 Apr 2024",
    price: "$56.99",
  },
  {
    id: 853,
    name: "Python Programming",
    viewLink: "/lms/course-details",
    category: "Science",
    instructor: { name: "Ava Cooper", image: "/images/users/user7.jpg" },
    enrolled: 250,
    startDate: "20 Mar 2024",
    endDate: "20 Apr 2024",
    price: "$45.32",
  },
];

const ITEMS_PER_PAGE = 5;

const Courses: React.FC = () => {
  // selectedOption state
  const [selectedOption, setSelectedOption] = useState<string>("All Courses");

  const handleSelect = (option: string) => {
    setSelectedOption(option);
    console.log(`Selected option: ${option}`); // Add your logic here
  };

  // Table
  const [courses, setCourses] = useState<Course[]>(initialCourses);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const totalPages = Math.ceil(courses.length / ITEMS_PER_PAGE);

  const displayedCourses = courses.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handlePageChange = (page: number) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const handleDelete = (id: number) => {
    setCourses((prev) => prev.filter((course) => course.id !== id));
  };

  return (
    <>
      <div className="trezo-card bg-white dark:bg-[#0c1427] mb-[25px] p-[20px] md:p-[25px] rounded-md">
        <div className="trezo-card-header mb-[20px] md:mb-[25px] flex items-center justify-between">
          <div className="trezo-card-title">
            <h5 className="!mb-0">Courses</h5>
          </div>

          <div className="trezo-card-subtitle">
            <Menu as="div" className="trezo-card-dropdown relative">
              <MenuButton className="trezo-card-dropdown-btn inline-block transition-all hover:text-primary-500">
                <span className="inline-block relative ltr:pr-[17px] ltr:md:pr-[20px] rtl:pl-[17px] rtl:ml:pr-[20px]">
                  {selectedOption}
                  <i className="ri-arrow-down-s-line text-lg absolute ltr:-right-[3px] rtl:-left-[3px] top-1/2 -translate-y-1/2"></i>
                </span>
              </MenuButton>

              <MenuItems
                transition
                className=" transition-all bg-white shadow-3xl rounded-md top-full py-[15px] absolute ltr:right-0 rtl:left-0 w-[195px] z-[50] dark:bg-dark dark:shadow-none data-[closed]:scale-95 data-[closed]:transform data-[closed]:opacity-0 data-[enter]:duration-100 data-[leave]:duration-75 data-[enter]:ease-out data-[leave]:ease-in"
              >
                {["Paid", "Free", "Top Rated", "Best Seller"].map((option) => (
                  <MenuItem
                    key={option}
                    as="div"
                    className={`block w-full transition-all text-black cursor-pointer ltr:text-left rtl:text-right relative py-[8px] px-[20px] hover:bg-gray-50 dark:text-white dark:hover:bg-black ${
                      selectedOption === option ? "font-semibold" : ""
                    }`}
                    onClick={() => handleSelect(option)}
                  >
                    {option}
                  </MenuItem>
                ))}
              </MenuItems>
            </Menu>
          </div>
        </div>

        <div className="trezo-card-content -mx-[20px] md:-mx-[25px]">
          <div className="table-responsive overflow-x-auto">
            <table className="w-full">
              <thead className="text-black dark:text-white">
                <tr>
                  {[
                    "ID",
                    "Course Name",
                    "Category",
                    "Instructor",
                    "Enrolled",
                    "Start Date",
                    "End Date",
                    "Price",
                    "Action",
                  ].map((header) => (
                    <th
                      key={header}
                      className="font-medium ltr:text-left rtl:text-right px-[20px] py-[11px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 bg-primary-50 dark:bg-[#15203c] whitespace-nowrap"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="text-black dark:text-white">
                {displayedCourses.map((course) => (
                  <tr key={course.id}>
                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <span className="text-gray-500 dark:text-gray-400">
                        {`#${course.id}`}
                      </span>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <Link
                        to={course.viewLink}
                        className="inline-block font-medium transition-all text-gray-500 dark:text-gray-400 hover:text-primary-500"
                      >
                        {course.name}
                      </Link>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      {course.category}
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <div className="flex items-center">
                        <div className="rounded-full w-[40px]">
                          <img
                            src={course.instructor.image}
                            alt={course.instructor.name}
                            className="inline-block rounded-full"
                            width={40}
                            height={40}
                          />
                        </div>
                        <div className="ltr:ml-[12px] rtl:mr-[12px]">
                          <span className="block font-medium">
                            {course.instructor.name}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <span className="text-gray-500 dark:text-gray-400">
                        {course.enrolled}
                      </span>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <span className="text-gray-500 dark:text-gray-400">
                        {course.startDate}
                      </span>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <span className="text-gray-500 dark:text-gray-400">
                        {course.endDate}
                      </span>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <span className="text-gray-500 dark:text-gray-400">
                        {course.price}
                      </span>
                    </td>

                    <td className="ltr:text-left rtl:text-right whitespace-nowrap px-[20px] py-[15px] md:ltr:first:pl-[25px] md:rtl:first:pr-[25px] ltr:first:pr-0 rtl:first:pl-0 border-b border-gray-100 dark:border-[#172036]">
                      <div className="flex items-center gap-[9px]">
                        <div className="relative group">
                          <Link to={course.viewLink}>
                            <button
                              type="button"
                              className="text-primary-500 leading-none"
                            >
                              <i className="material-symbols-outlined !text-md">
                                visibility
                              </i>
                            </button>
                          </Link>

                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            View
                            {/* Arrow */}
                            <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-white dark:border-[#172036] border-t-gray-800 dark:border-t-gray-800"></div>
                          </div>
                        </div>

                        <div className="relative group">
                          <button
                            type="button"
                            className="text-gray-500 leading-none"
                          >
                            <i className="material-symbols-outlined !text-md">
                              edit
                            </i>
                          </button>

                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            Edit
                            {/* Arrow */}
                            <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-white dark:border-[#172036] border-t-gray-800 dark:border-t-gray-800"></div>
                          </div>
                        </div>

                        <div className="relative group">
                          <button
                            type="button"
                            className="text-danger-500 leading-none"
                            onClick={() => handleDelete(course.id)}
                          >
                            <i className="material-symbols-outlined !text-md">
                              delete
                            </i>
                          </button>

                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs rounded px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            Delete
                            {/* Arrow */}
                            <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-white dark:border-[#172036] border-t-gray-800 dark:border-t-gray-800"></div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-[20px] md:px-[25px] pt-[12px] md:pt-[14px] sm:flex sm:items-center justify-between">
            <p className="!mb-0 !text-sm">
              Showing {displayedCourses.length} of {courses.length} results
            </p>

            <ol className="mt-[10px] sm:mt-0 space-x-1">
              <li className="inline-block">
                <button
                  type="button"
                  className="w-[31px] h-[31px] block leading-[29px] relative text-center rounded-md border border-gray-100 dark:border-[#172036] transition-all hover:bg-primary-500 hover:text-white hover:border-primary-500"
                  disabled={currentPage === 1}
                  onClick={() => handlePageChange(currentPage - 1)}
                >
                  <span className="opacity-0">0</span>
                  <i className="material-symbols-outlined left-0 right-0 absolute top-1/2 -translate-y-1/2">
                    chevron_left
                  </i>
                </button>
              </li>

              {[...Array(totalPages)].map((_, index) => (
                <li className="inline-block" key={index}>
                  <button
                    className={`w-[31px] h-[31px] block leading-[29px] relative text-center rounded-md border dark:border-[#172036] ${
                      currentPage === index + 1
                        ? "border-primary-500 bg-primary-500 text-white"
                        : "border-gray-100"
                    }`}
                    onClick={() => handlePageChange(index + 1)}
                  >
                    {index + 1}
                  </button>
                </li>
              ))}

              <li className="inline-block">
                <button
                  type="button"
                  className="w-[31px] h-[31px] block leading-[29px] relative text-center rounded-md border border-gray-100 dark:border-[#172036] transition-all hover:bg-primary-500 hover:text-white hover:border-primary-500"
                  disabled={currentPage === totalPages}
                  onClick={() => handlePageChange(currentPage + 1)}
                >
                  <span className="opacity-0">0</span>
                  <i className="material-symbols-outlined left-0 right-0 absolute top-1/2 -translate-y-1/2">
                    chevron_right
                  </i>
                </button>
              </li>
            </ol>
          </div>
        </div>
      </div>
    </>
  );
};

export default Courses;
